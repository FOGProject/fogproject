#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>

#include "log.h"
#include "socklib.h"
#include "udpcast.h"
#include "udpc-protoc.h"
#include "fifo.h"
#include "udp-receiver.h"
#include "util.h"
#include "produconsum.h"
#include "statistics.h"

#ifndef O_BINARY
# define O_BINARY 0
#endif

#ifndef O_SYNC
# define O_SYNC 0
#endif

#ifndef O_TRUNC
# define O_TRUNC 0
#endif

static int sendConnectReq(struct client_config *client_config,
			  struct net_config *net_config,
			  int haveServerAddress) {
    struct connectReq connectReq;

    if(net_config->flags & FLAG_PASSIVE)
	return 0;

    connectReq.opCode = htons(CMD_CONNECT_REQ);
    connectReq.reserved = 0;
    connectReq.capabilities = htonl(RECEIVER_CAPABILITIES);
    connectReq.rcvbuf = htonl(getRcvBuf(client_config->S_UCAST));
    if(haveServerAddress)
      return SSEND(connectReq);
    else
      return BCAST_CONTROL(client_config->S_UCAST, connectReq);
}

int sendGo(struct client_config *client_config) {
    struct go go;
    go.opCode = htons(CMD_GO);
    go.reserved = 0;
    return SSEND(go);
}

struct client_config *global_client_config=NULL;

static void fixConsole(void) {
    if(global_client_config)
	restoreConsole(&global_client_config->console,0);
}

static void sendDisconnectWrapper(void) {
    if(global_client_config)
	sendDisconnect(0, global_client_config);
}

void sendDisconnect(int exitStatus,
		    struct client_config *client_config) {    
    struct disconnect disconnect;
    disconnect.opCode = htons(CMD_DISCONNECT);
    disconnect.reserved = 0;
    SSEND(disconnect);
    if (exitStatus == 0)
	udpc_flprintf("Transfer complete.\007\n");
}


struct startTransferArgs {
    int fd;
    int pipeFd;
    struct client_config *client_config;
    int doWarn;
};

static int openOutFile(struct disk_config *disk_config)
{
    int outFile=1;
    if(disk_config->fileName != NULL) {
	int oflags = O_CREAT | O_WRONLY | O_TRUNC;
	if((disk_config->flags & FLAG_SYNC)) {
	    oflags |= O_SYNC;
	}
	outFile = open(disk_config->fileName, oflags | O_BINARY, 0644);
	if(outFile < 0) {
#ifdef NO_BB
#ifndef errno
	    extern int errno;
#endif
#endif
	    udpc_fatal(1, "open outfile %s: %s\n",
		       disk_config->fileName, strerror(errno));
	}
    } else {
#ifdef __MINGW32__
	_setmode(1, O_BINARY);
#endif
    }
    return outFile;
}

int startReceiver(int doWarn,
		  struct disk_config *disk_config,
		  struct net_config *net_config,
		  struct stat_config *stat_config,
		  const char *ifName)
{
    char ipBuffer[16];
    union serverControlMsg Msg;
    int connectReqSent=0;
    struct client_config client_config;
    int outFile=1;
    int pipedOutFile;
    struct sockaddr_in myIp;
    int pipePid = 0;
    int origOutFile;
    int haveServerAddress;
    int ret=0;

    client_config.sender_is_newgen = 0;

    net_config->net_if = getNetE 

staaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaant pipedOutFilRecArray( 0;

    net_coatic TNR if(udp_SOCKS)ewgen = 0;

    net_cdGo(str
	/* do _pc =(ADDR_TYPEGo(strut.sliceNo)),
aaaaaaaaaaaaaaaaaut.sliceNo)),d sectReq.rcPORTE)
	return 0;rticipant(getRcvB0;

    net_cdGB(str
	/* do _pc =(ADDR_TYPEGB(strut.sliceNo)),
aaaaaaaaaaaaaaaaaut.sliceNo)),d sectReq.rcPORTE)
	return 0;rticipant(ge_PASSIVE)
	return 0;ttlcomp1ice-    net_confi
#inRdvWeird. TimeouaaaBs)\nCsizeof(con(
aaaaaaaaaaaaaaaaaut.slPASS&
aaaaaaaaaaacqSent=0t(&configt.slPASSif
ifecPORTE)
	return 0;rticipant(ge_cot _pc =ToBs)\n",
	( 0;

    net_cdGo(strts(sendstig->defaaaa0t(&colleof(con(&
aaaaaaaaaaacqSent=0t(&configt.slPAS    net_confi
#inRdvgt.slPASif
ifecPORTE)
	return 0;rticipant(ge_		fre0t(&conficon(&
aaaaaaaaaaacqSent=0t(&confi    CLR_BITaa0t(&cDfiginap) (( 0;

    net_cdGo(str,,
aaaaaaaaaaaaaaaaaut.sli&
aaaaaaaaaaacqSent=0t(&confi endst->cotTtl( 0;

    net_cdGo(str,,
aaaaaaaaaaattl endst->>rxmitI0;

    net_cdGMAST, cTRL =t.s* do _pc =(ADDR_TYPEGM(strut.sl)),
aaaaaaaaaaaaaaaaaut.slASS&
aaaaaaaaaaacqSent=0t(&configt.slPASectReq.rcPORTE)
	return 0;rticipant(getoo ma/ TODO: subscribe anficonIT(cnclude " to!c int handleDi/

	rIp(&
aaaaaaaaaaarno));
    }

 clNo);
    %d (%d byteUDPcnclude " g) xts, 
	"ce, senerrno));
	}
 ;
  CREAT   break? ", slt tompicon   e, stre
	int oflags = O_CREAT   break? ")
{d	   ":
	int oflags = O_CREAlices_pc (%dMt o(
aaaaaaaaaaaaaaaaa
 clNo);
    %d (%d byy ofeName,,
aaaaaaaaaaaaaaaaaaaaREAlicetRcvBuf(client clint haveSer;

    client_congetNetE 

sI0;

    net_cI0;

 Number=UG
   ATURE_U number g) x. */
hron#if tt pipeFeue fore */
	slice =/blockSinion(retmsgSinion(retg;
   t from!Buf(client cli == 
	     ice_t *client_con&onfig *net_conrn 0;
    }
(slice1 != connectReq connectR_fatal(1	pifdef  slictonue;locTUREnnectR->rc.part->rxmitId+(client clint 1 10)
	 connectReq connec_newg	sblockS;
   selcli _pc( 0;

    net_coatic TNR if(udp_SOCKS
(slice1 != 

    slice->   in0;
	    coFEC) {
		natal(1	iver(in-1 10)
	 =/bl= get(char); ctReq, consgSin=    rsSlice, sendsMonfi 0;

    net_contReq con,,
aaaaaaaaaaarticipant(re  icnsgSin		natal(1es_pcifdef  nclvad;
}ue;locTUREnnectR->rc.part"Tra(ransmit	coFEC
		   stre0;

    net_contReq conf("Ha
lPASif
ifecPORTE)
	return 0;rticipant( too many  slad;
}uit pigh	   rtl participants answg	se CMD_OK:
	 Mon.ndleOk(sendsticip   flprierved = 0;PLY:ig->0;

    net_cI0;

 Number   }			  Mon.Id+(clienplynChaq, co  }
	    udpcze;
    in  }			  Mon.Id+(clienplyn             	e.\007\n");
}


  pthreadf("Timefi ap=%08lxd,
			  reeeeeceNo), }			  Mon.Id+(clienplynCABILITIES);t(getWS
	 			  Mon.Id+(clienplynCABILITIES);tO_SCAPmitS_GENe(sendst-> 0;

    net_config->net_if = get1data_pc,copyFd;
tSlice);&
aaaaaaaaaaarno));
    }
ut.sliceNoMon.Id+(clienplynmt(&confi end	    at (>0;

    net_cI0;

 Number   date(sendst->%s\n",
		      T	    udpI0;

 f
    } elId+(cliedgs {
 d	         ndef      }
dsticip   flpriHELLOrBlocks - :dsticip   flpriHELLOritS:dsticip   flpriHELLO:ig->fe(client clint havtWS
	 				 Mon.ndleOk(   dlpriHELLOrBlocks -      )
	return 0;

    sk_ = nrBlocks - getWS
	 			  Mon.confinCABILITIES);tO_SCAPmitS_GENe(sendst-> 0;

    net_config->net_if = get1data_pc,copyFd;
tSlice);&
aaaaaaaaaaarno));
    }
ut.sliceNoMon.confinmt(&confi end	 != 

    slice-ze;
    in  }			s Mon.confinblockSize, da FLAG_SN 			  Mon.confinCABILITIES);tO_SCAPmlprintf(  )
	return 0;

    sk_ = nrReq.opC da FLAG_SN 
	return 0;

    connectReq.opCode       ndef      }
d	    connectReq connec_1datacslice->isXmittp   flprierved = 0;Q:dsticip   flpri  re:dsticip   flpriFEC:atacslice->isXmitt command %	ndef WINDO
te.\007\
		     da FLAignedontReq", cly msg-. Ouitr tt pipeFat the gnnec?ame, strer    break;
    }
OK:
	 Mon.ndleOk(se<stripes;ndef      :clNo);
    %d (%d byCd+(cliedIT(c#ransmits>opCode)
sI0;

    net_cI0;

 NumberCode)
s
		IpSt	   tre0;

    net_contReq con,ontrolMsgt(ge_PASSaaa0yeof(con(
aaaaaaaaaaaaaaaaau &nt o(ge_PASSIVE!ipIsZtFi(&
aaaaaaaaaaarno));
    }

& FL
	rexmit!ipIsEqu	  &
aaaaaaaaaaarno));
    }
u &nt o( FL
	rexmit(ipIsZtFi(&
aaaaaaaaaaacqSent=0t(&confi  {
#	rexmit!ipIsEqu	  &
aaaaaaaaaaarno));
    }
u &
aaaaaaaaaaacqSent=0t(&confi 
	ticipant %d\n", clNo)Listenintf("Dmmanit(&cy ofeName, strerror
		IpSt	   tr
aaaaaaaaaaarno));
    }
u ntrolMsgt(ge	I0;

    net_cdGMAST,   re Ha
lPA* do _pc =(ADDR_TYPEGM(stru,
aaaaaaaaaaaaaaaaaue, sendstr
aaaaaaaaaaarno));
    }
u , sendstectReq.rcPORTE)
	return 0;rticipant(getRcvDO
tFLAG_SN 
	return 0;    (loedAST_FEC
intf("DroMAX_CLIENTS;  fec_blocksNR if(udp_SOCKS= SLICE_if( 0;

    net_coatic*(st! date
lPAs);
    if(haveServerAdcoatic*(s, 
	return 0;    (loedAST_FEC
e<stripes; st
    strdisk_config);
    if(dise<striddress;
   flags;
    int rr_in myIp;
 flags |P_inndef err,e
	int oflagu &;
    i(ge_PASSac void fixConsole(vo &;
    int pipedOutFTURxtSlice,(global_client_cose<stri{clNo;
	indif
 
    sn(retu, clU	   picon  PrnChe %s: %s\n"
  uldP, clU	   picon  Prn(ame)
{
    0;r, clU	   picon  Prnut.sli	striddress;
   ,rr_in myIp;
     	nclude "  sender_stateflaap masendblockSddress;
   ,t.sli		ame)
{
    0;ame)Period,t.sli		r, clU	   picon  Prnut.sli		ame)
{
    0;noPe gnnec(ge	pant %dblockSize&      

    slice-ze;
    i    	"
#in  confiec data");

	pthrea"
#in  coAST_FEC   nclude c_thre(haveServerAdcisS   i   if (eSYNC)) 
	return 0;

    co(nnectReq.opC|nnectNOKBD)(sendstihread_csconne    onsumeAnI0;

    net_cIsconne ice, sendstig->defaLL) {
isk_c)out and no rxmit sliceARN - : This will X_BIwrite}uit hard} *fifc_flpi* rechin(sendsteAnI0;

    net_cIsconne icpicpa>console,00dsteAnTURxtSl_client_co!atEnd) ,
		   idisk_conf&     &onfig *net_conrn 0;
    }
f((net_conwritenf&     rr_in myIp;
    dst->
    i(endsticiplose(r_in myIp;
    d}read, NULL);
}
I0;

    net_cRETURN netSended, send weransmisrr_innrnow ts.tvimeof
   
	  incoming
    i(endstici_is_d no ts.tFor");ccon(g
    i   P_in"   d}rrno;
#enY);
#endif
  f */
Sddress;
   le;
}

inihreY);
#endif
 inco net_codisk_conblockSize, ne1RN fecMainTS;  client_consendst->soc(global_client_conrn SSENDc void fixCon