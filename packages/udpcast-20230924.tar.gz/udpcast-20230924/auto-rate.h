#ifndef AUTO_RATE_H
#define AUTO_RATE_H

extern struct rateGovernor_t autoRate;

#endif /* AUTO_RATE_H */
