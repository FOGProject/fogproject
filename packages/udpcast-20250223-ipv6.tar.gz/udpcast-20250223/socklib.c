#include "config.h"

#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdint.h>
#include <errno.h>

#include <fcntl.h>

#ifdef HAVE_ARPA_INET_H
# include <arpa/inet.h>
#endif

#ifdef HAVE_NETDB_H
# include <netdb.h>
#endif

#ifdef HAVE_NET_IF_H
# include <net/if.h>
#endif

#ifdef HAVE_SYS_IOCTL_H
# include <sys/ioctl.h>
#endif

#ifdef HAVE_IFADDRS_H
/* For getifaddrs(): SIOCGIFCONF lists only IPv4 addresses */
# include <ifaddrs.h>
#endif

#ifdef __MINGW32__

#include <ws2tcpip.h>
#define ioctl ioctlsocket

#include <iprtrmib.h>
#include <iphlpapi.h>

#endif /* __MINGW32__ */

#include "log.h"
#include "socklib.h"
#include "util.h"
#include "strparse.h"

#ifndef SOL_IP
#define SOL_IP IPPROTO_IP
#endif

#ifdef __linux__

#include <linux/types.h>

typedef unsigned long long u64;
typedef unsigned int u32;
typedef unsigned short u16;
typedef unsigned char u8;

#include <linux/ethtool.h>
#include <linux/sockios.h>

#endif

// for Darwin
#ifdef _SIZEOF_ADDR_IFREQ
    #define IFREQ_SIZE(a) _SIZEOF_ADDR_IFREQ(a)
#endif

#ifdef LOSSTEST
/**
 * Packet loss/swap testing...
 */
long int write_loss = 0;
long int read_loss = 0;
long int read_swap = 0;
unsigned int seed=0;

int loseSendPacket(void) {
    if(write_loss) {
	long r = random();
	if(r < write_loss)
	    return 1;
    }
    return 0;
}

#define STASH_SIZE 64

static int stashed;
static struct packetStash {
    unsigned char data[4092];
    int size;
} packetStash[STASH_SIZE];

/**
 * Lose a packet
 */
void loseRecvPacket(int s) {
    if(read_loss) {
	while(random() < read_loss) {
	    int x;
	    flprintf("Losing packet\n");
	    recv(s, (void *) &x, sizeof(x),0);
	}
    }
    if(read_swap) {
	while(stashed < STASH_SIZE && random() < read_swap) {
	    int size;
	    flprintf("Stashing packet %d\n", stashed);
	    size = recv(s, packetStash[stashed].data,
			sizeof(packetStash[stashed].data),0);
	    packetStash[stashed].size = size;
	    stashed++;
	}
    }
}

/**
 * bring stored packet back up...
 */
int RecvMsg(int s, struct msghdr *msg, int flags) {
    if(read_swap && stashed) {
	if(random() / stashed < read_swap) {
	    int slot = random() % stashed;
	    int iovnr;
	    char *data = packetStash[slot].data;
	    int totalLen = packetStash[slot].size;
	    int retBytes=0;
	    flprintf("Bringing out %d\n", slot);
	    for(iovnr=0; iovnr < msg->msg_iovlen; iovnr++) {
		int len = msg->msg_iov[iovnr].iov_len;
		if(len > totalLen)
		    len = totalLen;
		memcpy(msg->msg_iov[iovnr].iov_base, data, len);
		totalLen -= len;
		data += len;
		retBytes += len;
		if(totalLen == 0)
		    break;
	    }
	    packetStash[slot]=packetStash[stashed];
	    stashed--;
	    return retBytes;
	}
    }
    return recvmsg(s, msg, flags);
}

void setWriteLoss(char *l) {
    write_loss = (long) (atof(l) * RAND_MAX);
}

void setReadLoss(char *l) {
    read_loss = (long) (atof(l) * RAND_MAX);
}

void setReadSwap(char *l) {
    read_swap = (long) (atof(l) * RAND_MAX);
}


void srandomTime(int printSeed) {
    struct timeval tv;
    long seed;
    gettimeofday(&tv, 0);
    seed = (tv.tv_usec * 2000) ^ tv.tv_sec;
    if(printSeed)
	flprintf("seed=%ld\n", seed);
    srandom(seed);
}
#endif

/* makes a socket address */
int makeSockAddr(char *hostname, in_port_t port, struct sockaddr_in *addr)
{
    struct hostent *host;

    memset ((char *) addr, 0, sizeof(struct sockaddr_in));
    if (hostname && *hostname) {
	host = gethostbyname(hostname);
	if (host == NULL) {
	    udpc_fatal(1, "Unknown host %s\n", hostname);
	}

	memcpy((void *)&((struct sockaddr_in *)addr)->sin_addr,
	       host->h_addr_list[0],
	       (size_t) host->h_length);
    }

    ((struct sockaddr_in *)addr)->sin_family = AF_INET;
    ((struct sockaddr_in *)addr)->sin_port = htons(port);
    return 0;
}

#define getSockaddrIn(addr) ((struct sockaddr_in *)(void*)(addr))
#define getSinAddr(addr) (getSockaddrIn(addr)->sin_addr)
#define getSockaddrIn6(addr) ((struct sockaddr_in6 *)(void*)(addr))

socklen_t getSockLen(struct sockaddr_storage *addr) {
#ifdef UDPC_IPV6
    if(addr->ss_family == AF_INET6)
	return sizeof(struct sockaddr_in6);
#endif
    return sizeof(struct sockaddr_in);
}

#ifdef UDPC_IPV6
/* Link-local unicast and link-scope multicast addresses only mean
 * something together with an interface. bind() refuses them without
 * one. */
static int needsScope(struct in6_addr *addr) {
    return IN6_IS_ADDR_LINKLOCAL(addr) || IN6_IS_ADDR_MC_LINKLOCAL(addr) ||
	IN6_IS_ADDR_MC_NODELOCAL(addr);
}

/* Parses an IPv6 address with an optional "%scope", as in fe80::1%eth0.
 * The scope is an interface name or index; it is 0 when not given.
 * Returns 1 if the text is valid. */
static int parseIp6(const char *text, struct in6_addr *addr,
		    uint32_t *scope) {
    char buffer[INET6_ADDRSTRLEN];
    const char *percent = strchr(text, '%');
    size_t len = percent ? (size_t) (percent - text) : strlen(text);

    *scope = 0;
    if(len >= sizeof(buffer))
	return 0;
    memcpy(buffer, text, len);
    buffer[len] = '\0';
    if(inet_pton(AF_INET6, buffer, addr) != 1)
	return 0;
    if(percent != NULL) {
	char *end;
	unsigned long index;
	/* A numeric scope is digits only and fits an interface index.
	 * strtoul alone would take a sign or spaces, and wrap. ERANGE
	 * catches an overflow where unsigned long is 32 bits. */
	errno = 0;
	index = strtoul(percent + 1, &end, 10);
	if(isdigit((unsigned char) percent[1]) && *end == '\0') {
	    if(errno == ERANGE || index == 0 || index > UINT32_MAX)
		return 0;
	    *scope = (uint32_t) index;
	} else
	    *scope = if_nametoindex(percent + 1);
	if(*scope == 0)
	    return 0;
    }
    return 1;
}
#endif /* UDPC_IPV6 */

#ifdef HAVE_PTON
# define INET_ATON(a,i) inet_pton(AF_INET,a,i)
#else
# ifdef HAVE_ATON
#  define INET_ATON(a,i) inet_aton(a,i)
# else

#ifndef INADDR_NONE
#define INADDR_NONE ((in_addr_t)-1)
#endif

static inline int INET_ATON(const char *a, struct in_addr *i) {
	i->s_addr=inet_addr(a);
	if(i->s_addr == INADDR_NONE && strcmp(a, "255.255.255.255"))
		return 0; /* Address invalid */
	return 1; /* Address valid */
}
# endif
#endif


/* mcast is the multicast address for ADDR_TYPE_MCAST, else unused.
 * A multicast address brings its own family; the other types take the
 * family of the interface, which is the family of the session. */
static int initSockAddress(addr_type_t addr_type,
			   net_if_t *net_if,
			   struct sockaddr_storage *mcast,
			   unsigned short port,
			   struct sockaddr_storage *sa) {
    struct sockaddr_in *addr = getSockaddrIn(sa);
    int family;

    if(!net_if && addr_type != ADDR_TYPE_MCAST)
	udpc_fatal(1, "initSockAddr without ifname\n");

    if(addr_type == ADDR_TYPE_MCAST)
	family = mcast ? mcast->ss_family : AF_INET;
    else
	family = net_if->family;

    memset ((char *) sa, 0, sizeof(*sa));

#ifdef UDPC_IPV6
    if(family == AF_INET6) {
	struct sockaddr_in6 *addr6 = getSockaddrIn6(sa);
	addr6->sin6_family = AF_INET6;
	addr6->sin6_port = htons(port);
	switch(addr_type) {
	case ADDR_TYPE_UCAST:
	    addr6->sin6_addr = net_if->addr6;
	    break;
	case ADDR_TYPE_BCAST:
	    /* IPv6 has no broadcast. A zero address already means
	     * "no broadcast on this interface" to the callers. */
	    break;
	case ADDR_TYPE_MCAST:
	    if(mcast) {
		addr6->sin6_addr = getSockaddrIn6(mcast)->sin6_addr;
		/* A scope given in the text (ff02::1%eth0) is kept. The
		 * group join and the send use the interface, so the two
		 * must name the same one. */
		addr6->sin6_scope_id = getSockaddrIn6(mcast)->sin6_scope_id;
		if(addr6->sin6_scope_id != 0 && net_if &&
		   net_if->ifindex6 != 0 &&
		   addr6->sin6_scope_id != net_if->ifindex6)
		    udpc_fatal(1, "Address scope and interface differ\n");
	    }
	    break;
	}
	if(addr6->sin6_scope_id == 0 && net_if &&
	   needsScope(&addr6->sin6_addr))
	    addr6->sin6_scope_id = net_if->ifindex6;
	return 0;
    }
#else
    (void) family;
#endif

    addr->sin_family = AF_INET;
    addr->sin_port = htons(port);

    switch(addr_type) {
    case ADDR_TYPE_UCAST:
	addr->sin_addr = net_if->addr;
	break;
    case ADDR_TYPE_BCAST:
	addr->sin_addr = net_if->bcast;
	break;
    case ADDR_TYPE_MCAST:
	addr->sin_addr.s_addr = mcast ? getSinAddr(mcast).s_addr : 0;
	break;
    }
    return 0;
}

int getMyAddress(net_if_t *net_if, struct sockaddr_storage *addr) {
    return initSockAddress(ADDR_TYPE_UCAST, net_if, NULL, 0, addr);
}


int getBroadCastAddress(net_if_t *net_if, struct sockaddr_storage *addr,
			in_port_t port){
    int r= initSockAddress(ADDR_TYPE_BCAST, net_if, NULL, port, addr);
    if(addr->ss_family == AF_INET && getSinAddr(addr).s_addr == 0) {
      /* Quick hack to make it work for loopback */
      struct sockaddr_storage ucast;
      initSockAddress(ADDR_TYPE_UCAST, net_if, NULL, port, &ucast);

      if((ntohl(getSinAddr(&ucast).s_addr) & 0xff000000) == 0x7f000000)
	getSinAddr(addr).s_addr = getSinAddr(&ucast).s_addr;
    }
    return r;
}

static int mcastListen(int sock, net_if_t *net_if,
		       struct sockaddr_storage *addr,
		       struct sockaddr_storage *src);

static int safe_inet_aton(const char *address, struct in_addr *ip) {
    if(!INET_ATON(address, ip))
	udpc_fatal(-1, "Bad address %s", address);
    return 0;
}


int getMcastAllAddress(net_if_t *net_if, struct sockaddr_storage *addr,
		       const char *address, in_port_t port){
    struct sockaddr_storage ip;

    clearIp(&ip);
    if(address == NULL || address[0] == '\0') {
#ifdef UDPC_IPV6
	/* IPv6 has no 224.0.0.1. Its all-nodes group ff02::1 has the
	 * same link scope and the same members. Snooping switches flood
	 * both. */
	if(net_if && net_if->family == AF_INET6)
	    setIpFromString(&ip, "ff02::1");
	else
#endif
	    setIpFromString(&ip, "224.0.0.1");
    } else
	setIpFromString(&ip, address);
    return initSockAddress(ADDR_TYPE_MCAST, net_if, &ip, port, addr);
}


ssize_t doSend(int s, void *message, size_t len, struct sockaddr_storage *to) {
/*    flprintf("sent: %08x %d\n", *(int*) message, len);*/
#ifdef LOSSTEST
    loseSendPacket();
#endif
    return sendto(s, message, len, 0, (struct sockaddr*) to, getSockLen(to));
}

ssize_t doReceive(int s, void *message, size_t len,
		  struct sockaddr_storage *from, in_port_t portBase) {
    socklen_t slen;
    ssize_t r;
    unsigned short port;
    char ipBuffer[INET6_ADDRSTRLEN];

    slen = sizeof(*from);
#ifdef LOSSTEST
    loseRecvPacket(s);
#endif
    r = recvfrom(s, message, len, 0, (struct sockaddr *)from, &slen);
    if (r < 0)
	return r;
    port = getPort(from);
    if(port != RECEIVER_PORT(portBase) && port != SENDER_PORT(portBase)) {
	udpc_flprintf("Bad message from port %s.%d\n",
		      getIpString(from, ipBuffer),
		      port);
	return -1;
    }
/*    flprintf("recv: %08x %d\n", *(int*) message, r);*/
    return r;
}

int getSendBuf(int sock) {
    int bufsize;
    socklen_t len=sizeof(int);
    if(getsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char*)&bufsize, &len) < 0) {
	perror("Get send buffer");
	return -1;
    }
    return bufsize;
}

void setSendBuf(int sock, unsigned int bufsize) {
    if(setsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char*)&bufsize, sizeof(bufsize))< 0)
	perror("Set send buffer");
}

unsigned int getRcvBuf(int sock) {
    unsigned int bufsize;
    socklen_t len=sizeof(int);
    if(getsockopt(sock, SOL_SOCKET, SO_RCVBUF, (char *)&bufsize, &len) < 0)
	return 0;
    return bufsize;
}

void setRcvBuf(int sock, unsigned int bufsize) {
    if(setsockopt(sock, SOL_SOCKET, SO_RCVBUF,
		  (char*) &bufsize, sizeof(bufsize))< 0)
	perror("Set receiver buffer");
}

int setSocketToBroadcast(int sock) {
    /* set the socket to broadcast */
    int p = 1;
    return setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char *)&p, sizeof(int));
}

int setTtl(int sock, int ttl) {
#ifdef UDPC_IPV6
    struct sockaddr_storage me;
    socklen_t len = sizeof(me);
    /* IPv6 calls the TTL the hop limit. It is set on the IPv6 level. */
    if(getsockname(sock, (struct sockaddr *) &me, &len) == 0 &&
       me.ss_family == AF_INET6)
	return setsockopt(sock, IPPROTO_IPV6, IPV6_MULTICAST_HOPS,
			  (char*)&ttl, sizeof(int));
#endif
    /* set the socket to broadcast */
    return setsockopt(sock, SOL_IP, IP_MULTICAST_TTL, (char*)&ttl, sizeof(int));
}

#ifdef HAVE_STRUCT_IP_MREQN_IMR_IFINDEX
# define IP_MREQN ip_mreqn
#else
# define IP_MREQN ip_mreq
#endif


/**
 * Fill in the mreq structure with the given interface and address
 */
static int fillMreq(net_if_t *net_if, struct in_addr addr,
		    struct IP_MREQN *mreq) {
#ifdef HAVE_STRUCT_IP_MREQN_IMR_IFINDEX
    mreq->imr_ifindex = net_if->index;
    mreq->imr_address.s_addr = 0;
#else
    mreq->imr_interface = net_if->addr;
#endif
    mreq->imr_multiaddr = addr;

    return 0;
}

/**
 * Perform a multicast operation
 */
static int mcastOp(int sock, net_if_t *net_if, struct in_addr addr,
		   int code, const char *message) {
    struct IP_MREQN mreq;
    int r;

    fillMreq(net_if, addr, &mreq);
    r = setsockopt(sock, SOL_IP, code, (char*)&mreq, sizeof(mreq));
    if(r < 0) {
	perror(message);
	exit(1);
    }
    return 0;
}


/*
struct in_addr getSinAddr(struct sockaddr_in *addr) {
    return ((struct sockaddr_in *) addr)->sin_addr;
}
*/

/**
 * Set socket to listen on given multicast address. Should be invoked only
 * on a socket also bound to the multicast address, in order not to accidentally
 * get traffic sent to another multicast address with same port.
 * For SSM networks (232.0.0.0/8), pass source of server as well, if available.
 */
static int mcastListen(int sock, net_if_t *net_if,
		       struct sockaddr_storage *addr,
		       struct sockaddr_storage *src) {
#ifdef UDPC_IPV6
    if(addr->ss_family == AF_INET6) {
	/* IPv6 joins every group any-source. Source-specific joins
	 * (ff3x::) are not ported; an any-source join still receives
	 * the data. */
	struct ipv6_mreq mreq6;
	mreq6.ipv6mr_multiaddr = getSockaddrIn6(addr)->sin6_addr;
	mreq6.ipv6mr_interface = net_if->ifindex6;
	if(setsockopt(sock, IPPROTO_IPV6, IPV6_JOIN_GROUP,
		      (char*)&mreq6, sizeof(mreq6)) < 0) {
	    perror("Subscribe to multicast group");
	    exit(1);
	}
	return 0;
    }
#endif
#ifdef IP_ADD_SOURCE_MEMBERSHIP
    if((getSinAddr(addr).s_addr & htonl(0xff000000)) == htonl(0xe8000000) &&
       src != NULL) {
	int r;
	struct ip_mreq_source ms;
	ms.imr_multiaddr = getSinAddr(addr);
	ms.imr_interface = net_if->addr;
	ms.imr_sourceaddr = getSinAddr(src);
	r=setsockopt(sock, SOL_IP, IP_ADD_SOURCE_MEMBERSHIP,
			  (char*)&ms, sizeof(ms));
	if(r < 0) {
	    perror("Subscribe to multicast group");
	    exit(1);
	}
	return 0;
    }
#endif
    return mcastOp(sock, net_if, getSinAddr(addr), IP_ADD_MEMBERSHIP,
		   "Subscribe to multicast group");
}


int setMcastDestination(int sock, net_if_t *net_if,
			struct sockaddr_storage *addr) {
#ifdef UDPC_IPV6
    if(addr->ss_family == AF_INET6) {
	/* IPv6 names the outgoing interface by its index */
	unsigned int ifindex = net_if->ifindex6;
	if(setsockopt(sock, IPPROTO_IPV6, IPV6_MULTICAST_IF,
		      (char*)&ifindex, sizeof(ifindex)) < 0) {
	    perror("Set multicast send interface");
	    exit(1);
	}
	return 0;
    }
#endif
#ifdef WINDOWS
    /* IP_MULTICAST_IF not correctly supported on Cygwin */
    int r;
    struct sockaddr_storage interface_addr;
    struct in_addr if_addr;
    getMyAddress(net_if, &interface_addr);
    if_addr = getSinAddr(&interface_addr);
    r = setsockopt (sock, IPPROTO_IP, IP_MULTICAST_IF,
		    (char *) &if_addr, sizeof(if_addr));
    if(r < 0)
	fatal(1, "Set multicast send interface");
    return 0;
#else
    return mcastOp(sock, net_if, getSinAddr(addr), IP_MULTICAST_IF,
		   "Set multicast send interface");
#endif
}


#ifdef __MINGW32__
static MIB_IFROW *getIfRow(MIB_IFTABLE *iftab, DWORD dwIndex) {
    int j;

    /* Find the corresponding interface row (for name and
     * MAC address) */
    for(j=0; j<iftab->dwNumEntries; j++) {
	MIB_IFROW *ifrow = &iftab->table[j];
	/* eth0, eth1, ... */
	if(ifrow->dwIndex == dwIndex)
	    return ifrow;
    }
    return NULL;
}

static char *fmtName(MIB_IFROW *ifrow) {
    char *out;
    int l = ifrow->dwDescrLen+1;
    if(ifrow->dwPhysAddrLen)
	l+=2+3*ifrow->dwPhysAddrLen;
    out = malloc(ifrow->dwDescrLen+l+1);
    if(!out)
	return NULL;
    memcpy(out, ifrow->bDescr, ifrow->dwDescrLen);
    out[ifrow->dwDescrLen]='\0';

    if(ifrow->dwPhysAddrLen) {
	int k;
	char *ptr=out+strlen(out);
	strcpy(ptr, " (");
	ptr+=2;
	for(k=0; k<ifrow->dwPhysAddrLen; k++) {
	    if(k)
		*ptr++='-';
	    sprintf(ptr, "%02x", 255 & ifrow->bPhysAddr[k]);
	    ptr += 2;
	}
	strcpy(ptr, ")");
    }
    return out;
}
#endif /* __MINGW32__ */

#ifndef __MINGW32__
/**
 * Tests whether the given card has link
 * 0 no
 * 1 yes
 * -1 unknown
 */
static uint32_t hasLink(int s, const char *ifname) {

#ifdef ETHTOOL_GLINK
  struct ifreq ifr;
  struct ethtool_value edata;

  edata.cmd = ETHTOOL_GLINK;

  strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name)-1);
  ifr.ifr_data = (char *) &edata;

  if(ioctl(s, SIOCETHTOOL, &ifr) == -1) {
    /* Operation not supported */
	  /* unknown link status still privileged over known
	   * disconnected */

    return 1;
  } else {
    return edata.data;
  }
#else
  return -1;
#endif
}
#endif

/**
 * Tests whether the given card operates in full duplex mode
 * 0 no
 * 1 yes
 * -1 unknown
 */
int isFullDuplex(int s, const char *ifname) {

#ifdef ETHTOOL_GLINK
  struct ifreq ifr;
  struct ethtool_cmd ecmd;

  ecmd.cmd = ETHTOOL_GSET;

  strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name)-1);
  ifr.ifr_data = (char *) &ecmd;

  if(ioctl(s, SIOCETHTOOL, &ifr) == -1) {
    /* Operation not supported */
    return -1;
  } else {
    return ecmd.duplex;
  }
#else
  return -1;
#endif
}


#ifndef __MINGW32__
/**
 * Base score of one interface address for getNetIf(), before the link
 * and broadcast bonuses. The IPv4 and the IPv6 scan share it, so both
 * rank interfaces the same way. Returns -1 if the interface does not
 * match "wanted".
 */
static int ifGoodness(const char *wanted, size_t wantedLen,
		      const char *name, int isWantedAddress,
		      int isZero, int isLoopback) {
    if(wanted) {
	if(isWantedAddress) {
	    return 8;
	} else if(strcmp(wanted, name) ==0) {
	    /* perfect match on interface name */
	    return 12;
	} else if(strncmp(wanted, name, wantedLen) ==0) {
	    /* prefix match on interface name */
	    return 7;
	} else {
	    /* no match, try next */
	    return -1;
	}
    } else {
	if(isZero) {
	    /* disregard interfaces whose address is zero */
	    return 1;
	} else if(isLoopback) {
	    /* disregard localhost type devices */
	    return 2;
	} else if(strcmp("eth0", name) == 0 ||
		  strcmp("en0",  name) == 0) {
	    /* prefer first ethernet interface */
	    return 6;
	} else if(strncmp("eth0:", name, 5) == 0) {
	    /* second choice: any secondary addresses of first ethernet */
	    return 5;
	} else if(strncmp("eth", name, 3) == 0 ||
		  strncmp("en",  name, 2) == 0) {
	    /* and, if not available, any other ethernet device */
	    return 4;
	} else {
	    return 3;
	}
    }
}
#endif /* __MINGW32__ */

#ifdef UDPC_IPV6
/**
 * IPv6 counterpart of the SIOCGIFCONF scan in getNetIf(). SIOCGIFCONF
 * returns only IPv4 addresses, so this uses getifaddrs(). It scores
 * addresses with the same ifGoodness(). IPv6 has no broadcast, so the
 * bonus that IPv4 gives a broadcast-capable interface goes to an
 * address that is not link-local instead: that is the address the
 * peers can route to.
 * If nothing matches, it returns NULL, or exits when mustFind is set.
 */
static net_if_t *getNetIf6(const char *wanted, int mustFind) {
    struct ifaddrs *ifap, *ifa, *chosen=NULL;
    struct in6_addr wantedAddress;
    uint32_t wantedScope;
    int isAddress=0;
    int lastGoodness=0;
    size_t wantedLen = wanted ? strlen(wanted) : 0;
    net_if_t *net_if;
    int s;

    if(wanted && parseIp6(wanted, &wantedAddress, &wantedScope))
	isAddress=1;

    if(getifaddrs(&ifap) < 0) {
	perror("udpcast: getifaddrs: ");
	exit(1);
    }

    s = socket(PF_INET6, SOCK_DGRAM, 0);
    if (s < 0) {
	perror("make socket");
	exit(1);
    }

    for(ifa = ifap; ifa != NULL; ifa = ifa->ifa_next) {
	struct in6_addr *iaddr;
	int goodness;

	if(ifa->ifa_addr == NULL || ifa->ifa_addr->sa_family != AF_INET6)
	    continue;
	iaddr = &getSockaddrIn6(ifa->ifa_addr)->sin6_addr;

	/* No "zero address" rung: getifaddrs() never lists :: */
	goodness = ifGoodness(wanted, wantedLen, ifa->ifa_name,
			      isAddress &&
			      IN6_ARE_ADDR_EQUAL(iaddr, &wantedAddress) &&
			      /* The same link-local can sit on two
			       * interfaces; a scope picks one of them */
			      (wantedScope == 0 ||
			       if_nametoindex(ifa->ifa_name) == wantedScope),
			      0, IN6_IS_ADDR_LOOPBACK(iaddr));
	if(goodness < 0)
	    continue;

	if(hasLink(s, ifa->ifa_name))
	    goodness += 3;

	goodness = goodness * 2;
	if(!IN6_IS_ADDR_LINKLOCAL(iaddr))
	    goodness++;

	if(goodness > lastGoodness) {
	    chosen = ifa;
	    lastGoodness = goodness;
	}
    }
    close(s);

    if(!chosen) {
	if(mustFind) {
	    fprintf(stderr, "No suitable IPv6 network interface found\n");
	    fprintf(stderr, "The following interfaces are available:\n");
	    for(ifa = ifap; ifa != NULL; ifa = ifa->ifa_next) {
		char buffer[INET6_ADDRSTRLEN];
		if(ifa->ifa_addr == NULL ||
		   ifa->ifa_addr->sa_family != AF_INET6)
		    continue;
		fprintf(stderr, "\t%s\t%s\n", ifa->ifa_name,
			inet_ntop(AF_INET6,
				  &getSockaddrIn6(ifa->ifa_addr)->sin6_addr,
				  buffer, sizeof(buffer)));
	    }
	    exit(1);
	}
	freeifaddrs(ifap);
	return NULL;
    }

    net_if = MALLOC(net_if_t);
    if(net_if == NULL)
	udpc_fatal(1, "Out of memory error");
    net_if->family = AF_INET6;
    net_if->name = strdup(chosen->ifa_name);
    net_if->addr6 = getSockaddrIn6(chosen->ifa_addr)->sin6_addr;
    net_if->ifindex6 = if_nametoindex(chosen->ifa_name);
#ifdef SIOCGIFINDEX
    net_if->index = (int) net_if->ifindex6;
#endif
    freeifaddrs(ifap);
    return net_if;
}
#endif /* UDPC_IPV6 */

/**
 * Canonize interface name. If attempt is not NULL, pick the interface
 * which has that address.
 * If attempt is NULL, pick interfaces in the following order of preference
 * 1. eth0
 * 2. Anything starting with eth0:
 * 3. Anything starting with eth
 * 4. Anything else
 * 5. localhost
 * 6. zero address
 * family is the address family that the addresses given on the command
 * line chose: AF_INET, AF_INET6, or AF_UNSPEC when none was given.
 * AF_INET6 scans the IPv6 addresses only. AF_UNSPEC is decided by an
 * IPv6 address given as the interface; otherwise IPv4 is scanned first,
 * as before, and IPv6 only if no IPv4 address matches.
 */
net_if_t *getNetIf(const char *wanted, int family) {
#ifndef __MINGW32__
	struct ifreq *ifrp, *chosen;
	uintptr_t ifend;
	struct ifconf ifc;
	int s;
	size_t wantedLen=0;
#else /* __MINGW32__ */
	int i;

	int etherNo=-1;
	int wantedEtherNo=-2; /* Wanted ethernet interface */

	MIB_IPADDRTABLE *iptab=NULL;
	MIB_IFTABLE *iftab=NULL;

	MIB_IPADDRROW *iprow, *chosen=NULL;
	MIB_IFROW *chosenIf=NULL;
	WORD wVersionRequested; /* Version of Winsock to load */
	WSADATA wsaData; /* Winsock implementation details */
	ULONG a;

#endif /* __MINGW32__ */

	int lastGoodness=0;
	struct in_addr wantedAddress;
	int isAddress=0;
	net_if_t *net_if;

	if(wanted == NULL) {
	    wanted = getenv("IFNAME");
	}

#ifdef UDPC_IPV6
	{
	    /* An address given as the interface must have the family that
	     * the other addresses chose. An IPv6 one alone makes the
	     * session IPv6. Without any hint, IPv4 is tried first. */
	    int wantedFamily = getAddrFamily(wanted);
	    if(family != AF_UNSPEC && wantedFamily != AF_UNSPEC &&
	       wantedFamily != family)
		udpc_fatal(1, "interface, mcast-rdv-address and "
			   "mcast-data-address are not the same address "
			   "family\n");
	    if(family == AF_UNSPEC && wantedFamily == AF_INET6)
		family = AF_INET6;
	    if(family == AF_INET6)
		return getNetIf6(wanted, 1);
	}
#else
	(void) family;
#endif /* UDPC_IPV6 */

	if(wanted && INET_ATON(wanted, &wantedAddress))
	    isAddress=1;
	else
	    wantedAddress.s_addr=0;

#ifndef __MINGW32__
	if(wanted)
	    wantedLen=strlen(wanted);
#endif /* __MINGW32__ */

	net_if = MALLOC(net_if_t);
	if(net_if == NULL)
	    udpc_fatal(1, "Out of memory error");

#ifndef __MINGW32__

	s = socket(PF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
	    perror("make socket");
	    exit(1);
	}

	ifc.ifc_len = sizeof(struct ifreq) * 10;
	while(1) {
	    int len = ifc.ifc_len;
	    ifc.ifc_buf = (caddr_t) malloc((size_t)ifc.ifc_len);
	    if(ifc.ifc_buf == NULL) {
		udpc_fatal(1, "Out of memory error");
	    }

	    if (ioctl(s, SIOCGIFCONF, (char *)&ifc) < 0 ||
		ifc.ifc_len < (signed int)sizeof(struct ifreq)) {
		perror("udpcast: SIOCGIFCONF: ");
		exit(1);
	    }

	    if(len == ifc.ifc_len) {
		ifc.ifc_len += sizeof(struct ifreq) * 10;
		free(ifc.ifc_buf);
	    } else
		break;
	}

	ifend = ((uintptr_t)ifc.ifc_req) + (uintptr_t) ifc.ifc_len;
	chosen=NULL;

	for (ifrp = ifc.ifc_req; (uintptr_t)ifrp < ifend; ifrp++) {
	    in_addr_t iaddr = getSinAddr(&ifrp->ifr_addr).s_addr;
	    int goodness;

	    if(ifrp->ifr_addr.sa_family != PF_INET)
		continue;

	    goodness = ifGoodness(wanted, wantedLen, ifrp->ifr_name,
				  isAddress && iaddr == wantedAddress.s_addr,
				  iaddr == 0, iaddr == htonl(0x7f000001));
	    if(goodness < 0)
		continue;

	    if(hasLink(s, ifrp->ifr_name))
	      /* Good or unknown link status privileged over known
	       * disconnected */
	      goodness += 3;

	    /* If all else is the same, prefer interfaces that
	     * have broadcast */
	    goodness = goodness * 2;
	    if(goodness >= lastGoodness) {
		/* Privilege broadcast-enabled interfaces */
		if(ioctl(s,  SIOCGIFBRDADDR, ifrp) < 0)
		    udpc_fatal(-1, "Error getting broadcast address for %s: %s",
			       ifrp->ifr_name, strerror(errno));
		if(getSinAddr(&ifrp->ifr_ifru.ifru_broadaddr).s_addr)
		    goodness++;
	    }

	    if(goodness > lastGoodness) {
		chosen = ifrp;
		lastGoodness = goodness;
		net_if->addr.s_addr = iaddr;
	    }
	}


#ifdef UDPC_IPV6
	if(!chosen && family == AF_UNSPEC) {
	    /* No IPv4 address matched. The interface may be IPv6-only.
	     * This changes only a case that used to fail with "No
	     * suitable network interface found"; a match on IPv4 still
	     * wins as before. */
	    net_if_t *net_if6 = getNetIf6(wanted, 0);
	    if(net_if6 != NULL) {
		close(s);
		free(ifc.ifc_buf);
		free(net_if);
		return net_if6;
	    }
	}
#endif

	if(!chosen) {
	    fprintf(stderr, "No suitable network interface found\n");
	    fprintf(stderr, "The following interfaces are available:\n");

	    for (ifrp = ifc.ifc_req ; (uintptr_t)ifrp < ifend; ifrp++) {
		char buffer[INET6_ADDRSTRLEN];

		if(ifrp->ifr_addr.sa_family != PF_INET)
		    continue;

		fprintf(stderr, "\t%s\t%s\n",
			ifrp->ifr_name,
			udpc_getIpString((struct sockaddr_storage *)
					 (void *) &ifrp->ifr_addr, buffer)
			);
	    }
	    exit(1);
	}

	net_if->family = AF_INET;
	net_if->name = strdup(chosen->ifr_name);

#ifdef HAVE_STRUCT_IP_MREQN_IMR_IFINDEX
	/* Index for multicast subscriptions */
	if(ioctl(s,  SIOCGIFINDEX, chosen) < 0)
	    udpc_fatal(-1, "Error getting index for %s: %s", net_if->name,
		       strerror(errno));
	net_if->index = chosen->ifr_ifindex;
#endif

	/* Broadcast */
	if(ioctl(s,  SIOCGIFBRDADDR, chosen) < 0)
	    udpc_fatal(-1, "Error getting broadcast address for %s: %s",
		       net_if->name, strerror(errno));
	net_if->bcast = getSinAddr(&chosen->ifr_ifru.ifru_broadaddr);

	close(s);
	free(ifc.ifc_buf);

#else /* __MINGW32__ */

	/* WINSOCK initialization */
	wVersionRequested = MAKEWORD(2, 0); /* Request Winsock v2.0 */
	if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */ {
	    fprintf(stderr,"WSAStartup() failed");
	    exit(1);
	}
	/* End WINSOCK initialization */


	a=0;
	GetIpAddrTable(iptab, &a, TRUE);
	iptab=malloc(a);
	GetIpAddrTable(iptab, &a, TRUE);

	a=0;
	GetIfTable(iftab, &a, TRUE);
	iftab=malloc(a);
	GetIfTable(iftab, &a, TRUE);

	if(wanted && !strncmp(wanted, "eth", 3) && wanted[3]) {
	    char *ptr;
	    int n = strtoul(wanted+3, &ptr, 10);
	    if(!*ptr)
		wantedEtherNo=n;
	}

	for(i=0; i<iptab->dwNumEntries; i++) {
	    int goodness=-1;
	    unsigned long iaddr;
	    int isEther=0;
	    MIB_IFROW *ifrow;

	    iprow = &iptab->table[i];
	    iaddr = iprow->dwAddr;

	    ifrow = getIfRow(iftab, iprow->dwIndex);

	    if(ifrow && ifrow->dwPhysAddrLen == 6 && iprow->dwBCastAddr) {
		isEther=1;
		etherNo++;
	    }

	    if(wanted) {
		if(isAddress && iaddr == wantedAddress.s_addr) {
		    goodness=8;
		} else if(isEther && wantedEtherNo == etherNo) {
			goodness=9;
		} else if(ifrow->dwPhysAddrLen) {
		    int j;
		    const char *ptr=wanted;
		    for(j=0; *ptr && j<ifrow->dwPhysAddrLen; j++) {
			int digit = strtoul(ptr, (char**)&ptr, 16);
			if(digit != ifrow->bPhysAddr[j])
			    break; /* Digit mismatch */
			if(*ptr == '-' || *ptr == ':') {
			    ptr++;
			}
		    }
		    if(!*ptr && j == ifrow->dwPhysAddrLen) {
			goodness=9;
		    }
		}
	    } else {
		if(iaddr == 0) {
		    /* disregard interfaces whose address is zero */
		    goodness = 1;
		} else if(iaddr == htonl(0x7f000001)) {
		    /* disregard localhost type devices */
		    goodness = 2;
		} else if(isEther) {
		    /* prefer ethernet */
		    goodness = 6;
		} else if(ifrow->dwPhysAddrLen) {
		    /* then prefer interfaces which have a physical address */
		    goodness = 4;
		} else {
		    goodness = 3;
		}
	    }

	    goodness = goodness * 2;
	    /* If all else is the same, prefer interfaces that
	     * have broadcast */
	    if(goodness >= lastGoodness) {
		/* Privilege broadcast-enabled interfaces */
		if(iprow->dwBCastAddr)
		    goodness++;
	    }

	    if(goodness > lastGoodness) {
		chosen = iprow;
		chosenIf = ifrow;
		lastGoodness = goodness;
	    }
	}

	if(!chosen) {
	    fprintf(stderr, "No suitable network interface found%s%s\n",
		    wanted ? " for " : "", wanted ? wanted : "");
	    fprintf(stderr, "The following interfaces are available:\n");

	    for(i=0; i<iptab->dwNumEntries; i++) {
		char buffer[INET6_ADDRSTRLEN];
		struct sockaddr_storage addr;
		MIB_IFROW *ifrow;
		char *name=NULL;
		iprow = &iptab->table[i];
		addr.ss_family = AF_INET;
		getSinAddr(&addr).s_addr = iprow->dwAddr;
		ifrow = getIfRow(iftab, iprow->dwIndex);
		name = fmtName(ifrow);
		fprintf(stderr, " %15s  %s\n",
			udpc_getIpString(&addr, buffer),
			name ? name : "");
		if(name)
		    free(name);
	    }
	    exit(1);
	}

	net_if->family = AF_INET;
	net_if->bcast.s_addr = net_if->addr.s_addr = chosen->dwAddr;
	if(chosen->dwBCastAddr)
	    net_if->bcast.s_addr |= ~chosen->dwMask;
	if(chosenIf) {
	    net_if->name = fmtName(chosenIf);
	} else {
	    net_if->name = "*";
	}
	free(iftab);
	free(iptab);
#endif /* __MINGW32__ */

	return net_if;
}

/**
 * @param addr_type
 *   UCAST - my unicast address attached to this device
 *   BCAST - my broadcast addres attached to this device
 *   MCAST - multicast address
 * @param ifname
 *   Interface name
 * @param mcast
 *   Multicast address (only used if type MCAST)
 * @param port
 *   Port to bind address to
 */
int makeSocket(addr_type_t addr_type,
	       net_if_t *net_if,
	       struct sockaddr_storage *tmpl,
	       in_port_t port,
	       struct sockaddr_storage *src) {
    int ret, s;
    struct sockaddr_storage myaddr;

#ifdef WINDOWS
    static int lastSocket=-1;
    /* Very ugly hack, but hey!, this is for Windows */

    if(addr_type == ADDR_TYPE_MCAST) {
	mcastListen(lastSocket, net_if, tmpl, src);
	return -1;
    } else if(addr_type != ADDR_TYPE_UCAST)
	return -1;
#endif

    /* All sockets of a session have the family of its interface */
#ifdef UDPC_IPV6
    s = socket(net_if->family == AF_INET6 ? PF_INET6 : PF_INET,
	       SOCK_DGRAM, 0);
#else
    s = socket(PF_INET, SOCK_DGRAM, 0);
#endif
    if (s < 0) {
	perror("make socket");
	exit(1);
    }

    ret = initSockAddress(addr_type, net_if,
			  addr_type == ADDR_TYPE_MCAST ? tmpl : NULL,
			  port, &myaddr);
    if(ret < 0)
	udpc_fatal(1, "Could not get socket address fot %d/%s",
		   addr_type, net_if->name);
    if(addr_type == ADDR_TYPE_BCAST && ipIsZero(&myaddr)) {
      /* Attempting to bind to broadcast address on not-broadcast media ... */
      closesocket(s);
      return -1;
    }
    ret = bind(s, (struct sockaddr *) &myaddr, getSockLen(&myaddr));
    if (ret < 0) {
	char buffer[INET6_ADDRSTRLEN];
	udpc_fatal(1, "bind socket to %s:%d (%s)\n",
		   udpc_getIpString(&myaddr, buffer),
		   udpc_getPort(&myaddr),
		   strerror(errno));
    }

    if(addr_type == ADDR_TYPE_MCAST)
	mcastListen(s, net_if, &myaddr, src);
#ifdef WINDOWS
    lastSocket=s;
#endif
    return s;
}

void printMyIp(net_if_t *net_if)
{
    char buffer[INET6_ADDRSTRLEN];
    struct sockaddr_storage myaddr;

    getMyAddress(net_if, &myaddr);
    udpc_flprintf("%s", udpc_getIpString(&myaddr,buffer));
}

char *udpc_getIpString(struct sockaddr_storage *addr, char *buffer) {
    unsigned long iaddr;
#ifdef UDPC_IPV6
    if(addr->ss_family == AF_INET6) {
	/* Plain address, no brackets and no %scope, so that it stays one
	 * word in "New connection from %s" and "Disconnecting #%d (%s)" */
	return (char *) inet_ntop(AF_INET6, &getSockaddrIn6(addr)->sin6_addr,
				  buffer, INET6_ADDRSTRLEN);
    }
#endif
    iaddr = htonl(getSinAddr(addr).s_addr);
    sprintf(buffer,"%ld.%ld.%ld.%ld",
	    (iaddr >> 24) & 0xff,
	    (iaddr >> 16) & 0xff,
	    (iaddr >>  8) & 0xff,
	    iaddr & 0xff);
    return buffer;
}

int ipIsEqual(struct sockaddr_storage *left, struct sockaddr_storage *right) {
#ifdef UDPC_IPV6
    if(left->ss_family == AF_INET6 || right->ss_family == AF_INET6)
	return left->ss_family == right->ss_family &&
	    IN6_ARE_ADDR_EQUAL(&getSockaddrIn6(left)->sin6_addr,
			       &getSockaddrIn6(right)->sin6_addr);
#endif
    return getSinAddr(left).s_addr == getSinAddr(right).s_addr;
}

int ipIsZero(struct sockaddr_storage *ip) {
#ifdef UDPC_IPV6
    if(ip->ss_family == AF_INET6)
	return IN6_IS_ADDR_UNSPECIFIED(&getSockaddrIn6(ip)->sin6_addr);
#endif
    return getSinAddr(ip).s_addr == 0;
}

/* sin_port and sin6_port sit at the same offset, so the port helpers
 * work for both families unchanged */
unsigned short udpc_getPort(struct sockaddr_storage *addr) {
    return ntohs(((struct sockaddr_in *) addr)->sin_port);
}

void setPort(struct sockaddr_storage *addr, unsigned short port) {
    ((struct sockaddr_in *) addr)->sin_port = htons(port);
}


void clearIp(struct sockaddr_storage *addr) {
    /* Also clear the IPv6 fields, so that the address reads as zero
     * whatever family is set on it later. The port is kept, as before. */
#ifdef UDPC_IPV6
    getSockaddrIn6(addr)->sin6_flowinfo = 0;
    memset(&getSockaddrIn6(addr)->sin6_addr, 0, sizeof(struct in6_addr));
    getSockaddrIn6(addr)->sin6_scope_id = 0;
#endif
    getSinAddr(addr).s_addr = 0;
    addr->ss_family = AF_INET;
}

void setIpFromString(struct sockaddr_storage *addr, const char *ip) {
#ifdef UDPC_IPV6
    /* Only IPv6 addresses contain a colon. Everything else is parsed
     * as before, with the same error. A "%scope" suffix is kept in
     * sin6_scope_id. */
    if(strchr(ip, ':') != NULL) {
	struct sockaddr_in6 *addr6 = getSockaddrIn6(addr);
	uint32_t scope;
	if(!parseIp6(ip, &addr6->sin6_addr, &scope))
	    udpc_fatal(-1, "Bad address %s", ip);
	addr6->sin6_flowinfo = 0;
	addr6->sin6_scope_id = scope;
	addr6->sin6_family = AF_INET6;
	return;
    }
#endif
    safe_inet_aton(ip, &getSinAddr(addr));
    addr->ss_family = AF_INET;
}

void copyIpFrom(struct sockaddr_storage *dst, struct sockaddr_storage *src) {
#ifdef UDPC_IPV6
    if(src->ss_family == AF_INET6) {
	getSockaddrIn6(dst)->sin6_flowinfo = 0;
	getSockaddrIn6(dst)->sin6_addr = getSockaddrIn6(src)->sin6_addr;
	getSockaddrIn6(dst)->sin6_scope_id = getSockaddrIn6(src)->sin6_scope_id;
    } else
#endif
	getSinAddr(dst) = getSinAddr(src);
    dst->ss_family = src->ss_family;
}

void getDefaultMcastAddress(net_if_t *net_if, struct sockaddr_storage *mcast) {
    getMyAddress(net_if, mcast);
#ifdef UDPC_IPV6
    if(mcast->ss_family == AF_INET6) {
	/* ff15::7564:0:X:Y, where X:Y are the low 32 bits of the sender's
	 * address. Like the IPv4 default (233.254/15 plus the low address
	 * bits), senders on one link get different groups, and the low 32
	 * bits are also the Ethernet multicast MAC (33:33:...), so
	 * switches keep them apart. ff15 is a transient, site-scope
	 * group: like the IPv4 group, it can cross routers as far as
	 * --ttl allows. 7564 is "ud", for udpcast. */
	struct sockaddr_in6 *mcast6 = getSockaddrIn6(mcast);
	memset(mcast6->sin6_addr.s6_addr, 0, 12);
	mcast6->sin6_addr.s6_addr[0] = 0xff;
	mcast6->sin6_addr.s6_addr[1] = 0x15;
	mcast6->sin6_addr.s6_addr[8] = 0x75;
	mcast6->sin6_addr.s6_addr[9] = 0x64;
	mcast6->sin6_scope_id = 0;
	return;
    }
#endif
    getSinAddr(mcast).s_addr &= htonl(0x0001ffff);
    getSinAddr(mcast).s_addr |= htonl(0xe9fe0000);
    
}


/* family is the session's. The message has room for 16 bytes. IPv4
 * still copies only 4, so an IPv4 session sends what it always sent. An
 * IPv6 session always fills all 16, zero if the address is cleared. */
void copyToMessage(unsigned char *dst, struct sockaddr_storage *src,
		   int family) {
#ifdef UDPC_IPV6
    if(family == AF_INET6) {
	if(src->ss_family == AF_INET6)
	    memcpy(dst, &getSockaddrIn6(src)->sin6_addr,
		   sizeof(struct in6_addr));
	else
	    memset(dst, 0, sizeof(struct in6_addr));
	return;
    }
#else
    (void) family;
#endif
    memcpy(dst, (char *) &getSinAddr(src),
	   sizeof(struct in_addr));
}


/* family is the session's, taken from the sender's address. */
void copyFromMessage(struct sockaddr_storage *dst, unsigned char *src,
		     int family) {
#ifdef UDPC_IPV6
    if(family == AF_INET6) {
	struct sockaddr_in6 *dst6 = getSockaddrIn6(dst);
	dst6->sin6_family = AF_INET6;
	dst6->sin6_flowinfo = 0;
	dst6->sin6_scope_id = 0;
	memcpy(&dst6->sin6_addr, src, sizeof(struct in6_addr));
	return;
    }
#else
    (void) family;
#endif
    memcpy((char *) &getSinAddr(dst), src, sizeof(struct in_addr));
}

int isAddressEqual(struct sockaddr_storage *a, struct sockaddr_storage *b) {
#ifdef UDPC_IPV6
    if(a->ss_family == AF_INET6 || b->ss_family == AF_INET6)
	/* Family, port and address, like the 8 bytes compared for IPv4 */
	return a->ss_family == b->ss_family &&
	    getSockaddrIn6(a)->sin6_port == getSockaddrIn6(b)->sin6_port &&
	    IN6_ARE_ADDR_EQUAL(&getSockaddrIn6(a)->sin6_addr,
			       &getSockaddrIn6(b)->sin6_addr);
#endif
    return !memcmp((char *) a, (char *)b, 8);
}

int getAddrFamily(const char *address) {
    struct in_addr addr;
    if(address == NULL)
	return AF_UNSPEC;
    if(strchr(address, ':') != NULL) {
#ifdef UDPC_IPV6
	struct in6_addr addr6;
	uint32_t scope;
	return parseIp6(address, &addr6, &scope) ? AF_INET6 : AF_UNSPEC;
#else
	/* An IPv4-only build has no other family to offer */
	return AF_UNSPEC;
#endif
    }
    return INET_ATON(address, &addr) ? AF_INET : AF_UNSPEC;
}

in_addr_t getIpv4Addr(struct sockaddr_storage *addr) {
#ifdef UDPC_IPV6
    if(addr->ss_family == AF_INET6)
	return 0;
#endif
    return getSinAddr(addr).s_addr;
}

unsigned int parseSize(char *sizeString) {
    char *eptr;
    unsigned int size = strtoui(sizeString, &eptr, 10);
    if(eptr && *eptr) {
	switch(*eptr) {
	    case 'm':
	    case 'M':
		size *= 1024 * 1024;
		break;
	    case 'k':
	    case 'K':
		size *= 1024;
		break;
	    case '\0':
		break;
	    default:
		udpc_fatal(1, "Unit %c unsupported\n", *eptr);
	}
    }
    return size;
}

void zeroSockArray(int *socks, int nr) {
    int i;

    for(i=0; i<nr; i++)
	socks[i] = -1;
}

int selectSock(int *socks, int nr, int startTimeout) {
    fd_set read_set;
    int r;
    int maxFd;
    struct timeval tv, *tvp;
    if(startTimeout) {
	tv.tv_sec = startTimeout;
	tv.tv_usec = 0;
	tvp = &tv;
    } else {
	tvp = NULL;
    }
    maxFd = prepareForSelect(socks, nr, &read_set);
    r = select(maxFd+1, &read_set, NULL, NULL, tvp);
    if(r < 0)
	return r;
    return getSelectedSock(socks, nr, &read_set);
}

int prepareForSelect(int *socks, int nr, fd_set *read_set) {
    int i;
    int maxFd;
    FD_ZERO(read_set);
    maxFd=-1;
    for(i=0; i<nr; i++) {
	if(socks[i] == -1)
	    continue;
	FD_SET(socks[i], read_set);
	if(socks[i] > maxFd)
	    maxFd = socks[i];
    }
    return maxFd;
}

int getSelectedSock(int *socks, int nr, fd_set *read_set) {
    int i;
    for(i=0; i<nr; i++) {
	if(socks[i] == -1)
	    continue;
	if(FD_ISSET(socks[i], read_set))
	    return socks[i];
    }
    return -1;
}

void closeSock(int *socks, int nr, int target) {
    int i;
    int sock = socks[target];

    socks[target]=-1;
    for(i=0; i<nr; i++)
	if(socks[i] == sock)
	    return;
    closesocket(sock);
}

int isMcastAddress(struct sockaddr_storage *addr) {
    int ip;
#ifdef UDPC_IPV6
    if(addr->ss_family == AF_INET6)
	return IN6_IS_ADDR_MULTICAST(&getSockaddrIn6(addr)->sin6_addr);
#endif
    ip = ntohl(getSinAddr(addr).s_addr) >> 24;
    return ip >= 0xe0 && ip < 0xf0;
}


#ifdef __MINGW32__

static ssize_t getLength(const struct msghdr *msg) {
    ssize_t size=0;
    int i;

    for(i=0; i<msg->msg_iovlen; i++) {
	size += msg->msg_iov[i].iov_len;
    }
    return size;
}

static void doCopy(const struct msghdr *msg, char *ptr, int n, int dir) {
    int i;
    for(i=0; n >=0 && i<msg->msg_iovlen; i++) {
	int l = msg->msg_iov[i].iov_len;
	if(l > n)
	    l = n;
	if(dir) {
	    memcpy(msg->msg_iov[i].iov_base, ptr, l);
	} else {
	    memcpy(ptr, msg->msg_iov[i].iov_base, l);
	}
	n   -= l;
	ptr += l;
    }
}

ssize_t recvmsg(int s, struct msghdr *msg, int flags) {
    ssize_t size=getLength(msg);
    char *buffer = malloc(size);
    int n; /* bytes left to copy */

    if(buffer == NULL) {
	/* Out of memory */
	errno = ENOMEM;
	return -1;
    }
    n = recvfrom(s, buffer, size, flags,
		 msg->msg_name, &msg->msg_namelen);
    doCopy(msg, buffer, n, 1);
    free(buffer);
    return n;
}

ssize_t sendmsg (int fd, const struct msghdr *msg, int flags) {
    ssize_t size=getLength(msg);
    char *buffer = malloc(size);
    int n;

    if(buffer == NULL) {
	/* Out of memory */
	errno = ENOMEM;
	return -1;
    }
    doCopy(msg, buffer, size, 0);
    n = sendto(fd, buffer, size, flags,
	       msg->msg_name, msg->msg_namelen);
    free(buffer);
    return n;
}


#endif /* __MINGW32__ */
