#ifndef SOCKLIB_H
#define SOCKLIB_H

#include <sys/types.h>
#include <string.h>

#ifdef HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif

#ifdef HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif

#ifdef HAVE_SYS_SOCKIO_H
#include <sys/sockio.h>
#endif

#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif

#ifdef HAVE_NETDB_H
#include <netdb.h>
#endif

#ifdef HAVE_WINSOCK2_H
#include <winsock2.h>
#endif

#ifdef __MINGW32__
/* socklen_t, for getSockLen() */
#include <ws2tcpip.h>
#endif

#ifdef HAVE_SYS_UIO_H
#include <sys/uio.h>
#endif

#ifdef __MINGW32__
#define WINDOWS
#undef USE_SYSLOG
#endif /* __MINGW32__ */

#ifdef __CYGWIN__
/* Untested so far ... */
#define WINDOWS
#endif

#ifndef HAVE_IN_ADDR_T
typedef unsigned long in_addr_t;
#endif

#ifndef HAVE_IN_PORT_T
typedef unsigned short in_port_t;
#endif

/* Large enough for an IPv6 address in text form */
#ifndef INET6_ADDRSTRLEN
#define INET6_ADDRSTRLEN 46
#endif

/* IPv6 needs the address family and these functions. Without them the
 * build is IPv4-only, and behaves as before. */
#if defined(AF_INET6) && defined(HAVE_INET_PTON) && \
    defined(HAVE_INET_NTOP) && defined(HAVE_IFADDRS_H) && \
    defined(HAVE_GETIFADDRS) && defined(HAVE_IF_NAMETOINDEX)
# define UDPC_IPV6 1
#endif

#define RECEIVER_PORT(x) (x)
#define SENDER_PORT(x) ((x)+1)

#define loseSendPacket udpc_loseSendPacket
#define loseRecvPacket udpc_loseRecvPacket
#define setWriteLoss udpc_setWriteLoss
#define setReadLoss udpc_setReadLoss
#define setReadSwap udpc_setReadSwap
#define srandomTime udpc_srandomTime
#define RecvMsg udpc_RecvMsg
#define doAutoRateLimit udpc_doAutoRateLimit
#define makeSockAddr udpc_makeSockAddr
#define getMyAddress udpc_getMyAddress
#define getBroadCastAddress udpc_getBroadCastAddress
#define getMcastAllAddress udpc_getMcastAllAddress
#define doSend udpc_doSend
#define doReceive udpc_doReceive
#define printMyIp udpc_printMyIp
#define makeSocket udpc_makeSocket
#define setSocketToBroadcast udpc_setSocketToBroadcast
#define setTtl udpc_setTtl
#define setMcastDestination udpc_setMcastDestination
#define isFullDuplex udpc_isFullDuplex
#define getNetIf udpc_getNetIf
#define getSendBuf udpc_getSendBuf
#define setSendBuf udpc_setSendBuf
#define getRcvBuf udpc_getRcvBuf
#define setRcvBuf udpc_setRcvBuf
#define getPort udpc_getPort
#define setPort udpc_setPort
#define getIpString udpc_getIpString
#define ipIsEqual udpc_ipIsEqual
#define ipIsZero udpc_ipIsZero
#define clearIp udpc_clearIp
#define setIpFromString udpc_setIpFromString
#define copyIpFrom udpc_copyIpFrom
#define getDefaultMcastAddress udpc_getDefaultMcastAddress
#define copyToMessage udpc_copyToMessage
#define copyFromMessage udpc_copyFromMessage
#define isAddressEqual udpc_isAddressEqual
#define getAddrFamily udpc_getAddrFamily
#define getIpv4Addr udpc_getIpv4Addr
#define getSockLen udpc_getSockLen
#define parseSize udpc_parseSize

#define zeroSockArray udpc_zeroSockArray
#define selectSock udpc_selectSock
#define prepareForSelect udpc_prepareForSelect
#define getSelectedSock udpc_getSelectedSock
#define closeSock udpc_closeSock


#ifdef LOSSTEST
int loseSendPacket(void);
void loseRecvPacket(int s);
void setWriteLoss(char *l);
void setReadLoss(char *l);
void setReadSwap(char *l);
void srandomTime(int printSeed);
int RecvMsg(int s, struct msghdr *msg, int flags);
#endif

struct net_if {
    struct in_addr addr;
    struct in_addr bcast;
    const char *name;
    /* The new fields stay above "index": SIOCGIFINDEX is defined only
     * in files that include the ioctl headers first, so the struct
     * layout after that point differs between files. */
    /* AF_INET or AF_INET6: the address family of the whole session */
    int family;
#ifdef UDPC_IPV6
    /* IPv6 only: the address, and the interface index used for
     * multicast and for the scope of link-local addresses */
    struct in6_addr addr6;
    unsigned int ifindex6;
#endif
#ifdef SIOCGIFINDEX
    int index;
#endif
};
typedef struct net_if net_if_t;

typedef enum addr_type_t {
  ADDR_TYPE_UCAST,
  ADDR_TYPE_MCAST,
  ADDR_TYPE_BCAST
} addr_type_t;

void doAutoRateLimit(int sock, int dir, int qsize, int size);

int makeSockAddr(char *hostname, in_port_t port, struct sockaddr_in *addr);

/* Addresses are held in a sockaddr_storage, so that one variable can hold
 * either an IPv4 or an IPv6 address. ss_family tells which. */
int getMyAddress(net_if_t *net_if, struct sockaddr_storage *addr);
int getBroadCastAddress(net_if_t *net_if,
			struct sockaddr_storage *addr, in_port_t port);
int getMcastAllAddress(net_if_t *net_if, struct sockaddr_storage *addr,
		       const char *address, in_port_t port);


ssize_t doSend(int s, void *message, size_t len, struct sockaddr_storage *to);
ssize_t doReceive(int s, void *message, size_t len,
		  struct sockaddr_storage *from, in_port_t portBase);

void printMyIp(net_if_t *net_if);


int makeSocket(addr_type_t addr_type, net_if_t *net_if, 
	       struct sockaddr_storage *tmpl, in_port_t port,
	       struct sockaddr_storage *src);

int setSocketToBroadcast(int sock);
int setTtl(int sock, int ttl);

int setMcastDestination(int,net_if_t *,struct sockaddr_storage *);
int isFullDuplex(int sock, const char *ifName);
/* family is AF_INET, AF_INET6, or AF_UNSPEC to choose from the
 * interface */
net_if_t *getNetIf(const char *ifName, int family);

int getSendBuf(int sock);
void setSendBuf(int sock, unsigned int bufsize);
unsigned int getRcvBuf(int sock);
void setRcvBuf(int sock, unsigned int bufsize);


#define SEND(s, msg, to) \
	doSend(s, &msg, sizeof(msg), &to)

#define RECV(s, msg, from, portBase ) \
	doReceive((s), &msg, sizeof(msg), &from, (portBase) )

#define BCAST_CONTROL(s, msg) \
	doSend(s, &msg, sizeof(msg), &net_config->controlMcastAddr)

unsigned short getPort(struct sockaddr_storage *addr);
void setPort(struct sockaddr_storage *addr, unsigned short port);
/* buffer must hold INET6_ADDRSTRLEN bytes */
char *getIpString(struct sockaddr_storage *addr, char *buffer);
int ipIsEqual(struct sockaddr_storage *left, struct sockaddr_storage *right);
int ipIsZero(struct sockaddr_storage *ip);

void clearIp(struct sockaddr_storage *addr);
void setIpFromString(struct sockaddr_storage *addr, const char *ip);

void copyIpFrom(struct sockaddr_storage *dst, struct sockaddr_storage *src);

void getDefaultMcastAddress(net_if_t *net_if, struct sockaddr_storage *mcast);

void copyToMessage(unsigned char *dst, struct sockaddr_storage *src,
		   int family);
void copyFromMessage(struct sockaddr_storage *dst, unsigned char *src,
		     int family);

int isAddressEqual(struct sockaddr_storage *a, struct sockaddr_storage *b);

/* AF_INET or AF_INET6 for a numeric address, AF_UNSPEC otherwise */
int getAddrFamily(const char *address);
/* The IPv4 address, or 0 for IPv6. For the rate governor interface,
 * which passes an in_addr_t. */
in_addr_t getIpv4Addr(struct sockaddr_storage *addr);
/* Length to pass to bind(), sendto() and sendmsg() for this address */
socklen_t getSockLen(struct sockaddr_storage *addr);

unsigned int parseSize(char *sizeString);

void zeroSockArray(int *socks, int nr);
int selectSock(int *socks, int nr, int startTimeout);
int prepareForSelect(int *socks, int nr, fd_set *read_set);
int getSelectedSock(int *socks, int nr, fd_set *read_set);
void closeSock(int *socks, int nr, int target);

int isMcastAddress(struct sockaddr_storage *addr);

int udpc_socklibFatal(int code);

#ifdef __MINGW32__ /* __MINGW32__ */

struct iovec {
    void *iov_base;
    int iov_len;
};
struct msghdr {
    void *msg_name;
    int msg_namelen;
    struct iovec *msg_iov;
    int msg_iovlen;

};

ssize_t sendmsg(int s, const struct msghdr *msg, int flags);
ssize_t recvmsg (int fd, struct msghdr *msg, int flags);

#define usleep(x) Sleep((x)/1000)
#define sleep(x) Sleep(1000L*(x))
#endif /* __MINGW32__ */

static inline void initMsgHdr(struct msghdr *hdr) {
#ifndef WINDOWS
    hdr->msg_control = 0;
    hdr->msg_controllen = 0;
    hdr->msg_flags = 0;
#endif
}

#ifndef __MINGW32__
#undef closesocket
#define closesocket(x) close(x)
#endif

#endif
